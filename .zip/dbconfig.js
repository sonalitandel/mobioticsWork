var config = {
    user: 'MyLogin',
    password: 'sonali',
    server: 'DESKTOP-MCBD479',
    database: 'mywork',
    options: {
      trustedconnection: true,
      enableArithAort: true,
      instancename: ''
    },
    port: 1433
  };
  
  module.exports = config;