export class UserData{
    id:number;
    UserName:string;
    Email:string;
    ProfilePictureUrl:string;
    Password:string;
    }