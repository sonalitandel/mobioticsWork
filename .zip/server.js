const express = require('express');
const app = new express();
const http = require('http');
const path = require('path');
const cors = require('cors');
var fs = require('fs');
var router = express.Router();
app.use(express.json({ limit: 105906176, extended: true }));
app.use(express.urlencoded({ extended: true }));

const dboperations = require('./dboperation.js');
app.use('/api', router);
 
app.use(cors({ origin: '*', }));
router.options('/api', cors()); // ADDED
app.use(function (req, res, next) {
   //Enabling CORS
   res.header("Access-Control-Allow-Origin", "*");
   res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
   res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, x-client-key, x-client-token, x-client-secret, Authorization");
   next();
});


router.route('/AllUserData').get(cors(), (request, response) => {
   dboperations.getUserData().then(result => {
      response.json(result[0]);
   })

})

router.route('/newUser').post(cors(), (request, response) => {
   let user = request.body
    console.log(request)
   dboperations.addUserData(user).then(result => {
      // result.header('Access-Control-Allow-Origin', '*');
      // result.header('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT');
      // result.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, x-client-key, x-client-token, x-client-secret, Authorization");

      response.status(201).json(result);
   })

})
const port = process.env.port || '3500';
app.set('port', port);
const server = http.createServer(app);
server.listen(port, () => { console.log(`Running on localhost:${port}`) });